package com.shashi.utility;

import jakarta.mail.MessagingException;

public class MailMessage {
	public static void registrationSuccess(String emailId, String name) {
		String recipient = emailId;
		String subject = "Registration Successfull";
		String htmlTextMessage = ""
			    + "<html>"
			    + "<body>"
			    + "<h2 style='color:green;'>Welcome to Grocery Store - Your One-Stop Shop for Daily Needs</h2>"
			    + "Hi " + name + ",<br><br>"
			    + "Thank you for choosing Grocery Store - your trusted partner for daily essentials. We're delighted to have you on board."
			    + "<br>"
			    + "Explore our latest collection of fresh groceries, dairy products, and household items, all curated just for you."
			    + "<br>"
			    + "Enjoy exclusive discounts of up to 60% on a wide range of grocery products."
			    + "<br><br>"
			    + "At Grocery Store, we are committed to delivering quality products at the best prices, right to your doorstep."
			    + "<br>"
			    + "To welcome you, we're offering an additional 10% discount, up to Rs. 500, on your first purchase."
			    + "<br>"
			    + "Simply use the promo code below at checkout:"
			    + "<br><br>"
			    + "PROMO CODE: <span style='color:green;'>GROCERY500</span>"
			    + "<br><br>"
			    + "Wishing you a fantastic shopping experience with us!"
			    + "<br>"
			    + "</body>"
			    + "</html>";



		try {
			JavaMailUtil.sendMail(recipient, subject, htmlTextMessage);
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void transactionSuccess(String recipientEmail, String name, String transId, double transAmount) {
		String recipient = recipientEmail;
		String subject = "Order Placed at Grocery Store - Your Trusted Online Grocery Partner";
		String htmlTextMessage = "<html>"
				    + "  <body>"
				    + "    <p>"
				    + "      Hey " + name + ",<br/><br/>"
				    + "      Thank you for choosing Grocery Store for all your grocery needs!"
				    + "      <br/><br/>"
				    + "      Your order has been successfully placed and is now being prepared for delivery."
				    + "      <br/><h6 style=\"color:gray;\">This is a demo project email, and no real transactions have been made.</h6>"
				    + "      <br/>"
				    + "      Here are your transaction details:<br/>"
				    + "      <br/>"
				    + "      <font style=\"color:red;font-weight:bold;\">Order ID:</font> "
				    + "      <font style=\"color:green;font-weight:bold;\">" + transId + "</font><br/>"
				    + "      <br/>"
				    + "      <font style=\"color:red;font-weight:bold;\">Amount Paid:</font> "
				    + "      <font style=\"color:green;font-weight:bold;\">" + transAmount + "</font>"
				    + "      <br/><br/>"
				    + "      Thank you for shopping with us!<br/><br/>"
				    + "      We look forward to serving you again soon!<br/>"
				    + "      <font style=\"color:green;font-weight:bold;\">Grocery Store - Your Trusted Grocery Partner</font>"
				    + "    </p>"
				    + "  </body>"
				    + "</html>";


		try {
			JavaMailUtil.sendMail(recipient, subject, htmlTextMessage);
		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}

	public static void orderShipped(String recipientEmail, String name, String transId, double transAmount) {
		String recipient = recipientEmail;
		String subject = "Your Order has been Shipped from Grocery Store";
		String htmlTextMessage = "<html>"
		    + "  <body>"
		    + "    <p>"
		    + "      Hey " + name + ",<br/><br/>"
		    + "      We're excited to share that your order has been shipped from Grocery Store -"
		    + "      <br/><br/>"
		    + "      Your order is now on its way to be delivered to you."
		    + "<br/><h6 style=\"color:gray;\">Please note that this is a demo project email, and no real transactions have been made.</h6>"
		    + "      <br/>"
		    + "      Here are your transaction details:<br/>"
		    + "      <br/>"
		    + "      <font style=\"color:red;font-weight:bold;\">Order ID:</font> "
		    + "      <font style=\"color:green;font-weight:bold;\">" + transId + "</font><br/>"
		    + "      <br/>"
		    + "      <font style=\"color:red;font-weight:bold;\">Amount Paid:</font> "
		    + "      <font style=\"color:green;font-weight:bold;\">" + transAmount + "</font>"
		    + "      <br/><br/>"
		    + "      Thank you for choosing Grocery Store!<br/><br/>"
		    + "      We hope you enjoy your purchase, and we look forward to serving you again soon!<br/>"
		    + "      <font style=\"color:green;font-weight:bold;\">Grocery Store</font>"
		    + "    </p>"
		    + "  </body>"
		    + "</html>";



		try {
			JavaMailUtil.sendMail(recipient, subject, htmlTextMessage);
		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}

	public static void productAvailableNow(String recipientEmail, String name, String prodName, String prodId) {
		String recipient = recipientEmail;
		String subject = "Product " + prodName + " is Now Available at Grocery Store ";
		String htmlTextMessage = "<html>"
		    + "  <body>"
		    + "    <p>"
		    + "      Hey " + name + ",<br/><br/>"
		    + "      We're excited to inform you that " + prodName + " is now available at Grocery Store !"
		    + "      <br/><br/>"
		    + "      Based on your recent browsing history, we noticed that you were interested in this product, but it was not available in sufficient quantity at that time."
		    + "<br/><h6 style=\"color:gray;\">Please note that this is a demo project email, and no real transactions have been made.</h6>"
		    + "      <br/>"
		    + "      Here are the details of the product now available for purchase:<br/>"
		    + "      <br/>"
		    + "      <font style=\"color:red;font-weight:bold;\">Product ID:</font> "
		    + "      <font style=\"color:green;font-weight:bold;\">" + prodId + "</font><br/>"
		    + "      <br/>"
		    + "      <font style=\"color:red;font-weight:bold;\">Product Name:</font> "
		    + "      <font style=\"color:green;font-weight:bold;\">" + prodName + "</font>"
		    + "      <br/><br/>"
		    + "      Thank you for shopping with us!<br/><br/>"
		    + "      We hope you enjoy your purchase, and we look forward to serving you again soon!<br/>"
		    + "      <font style=\"color:green;font-weight:bold;\">Grocery Store - Your Trusted Partner</font>"
		    + "    </p>"
		    + "  </body>"
		    + "</html>";



		try {
			JavaMailUtil.sendMail(recipient, subject, htmlTextMessage);
		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}

	public static String sendMessage(String toEmailId, String subject, String htmlTextMessage) {
		try {
			JavaMailUtil.sendMail(toEmailId, subject, htmlTextMessage);
		} catch (MessagingException e) {
			e.printStackTrace();
			return "FAILURE";
		}
		return "SUCCESS";
	}
}
