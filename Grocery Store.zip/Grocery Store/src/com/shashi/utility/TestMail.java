package com.shashi.utility;

import jakarta.mail.MessagingException;

public class TestMail {
	public static void main(String[] args) {
		try {
			String recipient = "Nursery.Store@gmail.com";
			String subject = "Mail Configuration Successfull";
String htmlTextMessage = "" + "<html>"
    + "<head><title>Welcome to Nursery Store</title><style>.greenText{color:green;} p{font-size:14px;}</style></head><body>"
    + "<h2 style='color:red;'>Welcome to Nursery Store</h2>" + "<p>Dear Parent,<br>"
    + "Thank you for choosing Nursery Store.<br>"
    + "We are excited to welcome your child into our growing community of young learners! We invite you to explore our range of programs designed for early childhood development."
    + "<br>We are offering up to <b>20% OFF</b> on admission fees for new enrollments. This is a great opportunity to get your child started on their educational journey with us.<br>"
    + "<br>Our nursery provides a nurturing and safe environment where children can grow, learn, and play. We are dedicated to providing high-quality care and education to help your child thrive."
    + " As a welcome gift for our new families, we are offering an additional 5% OFF on the first month's fee. To avail this offer, simply use the promo code below during registration.<br><br>"
    + "PROMO CODE: <span class='greenText'>BLOSSOM2024</span><br><br>" + "We look forward to a wonderful year ahead!<br>"
    + "Best Regards,<br>" + "Nursery Store Team" + "</p>" + "</body>" + "</html>";

			JavaMailUtil.sendMail(recipient, subject, htmlTextMessage);
			System.out.println("Mail Sent Successfully!");

		} catch (MessagingException e) {
			System.out.println("Mail Sending Failed With Error: " + e.getMessage());
			e.printStackTrace();
		}
	}

}
